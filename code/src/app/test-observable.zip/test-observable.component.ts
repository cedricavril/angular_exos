import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-observable',
  templateUrl: './test-observable.component.html',
  styleUrls: ['./test-observable.component.scss']
})
export class TestObservableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
